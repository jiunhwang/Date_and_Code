

function [optmParameter,modelparameter] =  initialization
% corelk5:  10^-3, 10^2, 10^6, 10^5
%        :  10^-3, 10^2, 10^5, 10^5
% iaprtc12: 10^-3, 10^2, 10^5, 10^4
% pascal07: 10^-1, 10^2, 10^5, 10^4
% espgame:  10^-3, 10^2, 10^5, 10^5
% mirflickr:10^-2, 10^2, 10^4, 10^5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% pascal-2   :10^-1, 10^2, 10^5, 10^4
% corel5k-2  :10^-3, 10^2, 10^5, 10^5
% espgame-2  :10^-3, 10^2, 10^5, 10^5
% iaprtc12-2 :10^-3, 10^2, 10^5, 10^4
% mirflickr-2:10^-2, 10^2, 10^4, 10^5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


    optmParameter.lambda1  = 10^-1; % sparse of Wv 
    optmParameter.lambda2  = 10^2;  % consistency of two different views 
    optmParameter.lambda3  = 10^5;  % constraint on the Wv's, pairwise label correlation
    optmParameter.lambda4  = 10^4;  % regularization on theta

    optmParameter.s        = 0.2;   % smooth parameter
    optmParameter.ru       = 1;     % initialize Wset
    optmParameter.eta      = 10;    % learning rate of lipchitz constant
    
    optmParameter.maxIter           = 30;
    optmParameter.minimumLossMargin = 0.000001;
    optmParameter.updateTheta       = 1;
    optmParameter.outputthetaQ      = 0;
    
    %% Model Parameters
    modelparameter.tuneThresholdType  = 1; % 1:Hloss, 2:Acc, 3:F1, 4:LabelBasedAccuracy, 5:LabelBasedFmeasure, 6:SubACC 
    modelparameter.crossvalidation    = 1; % {0,1}
    modelparameter.cv_num             = 5;
    modelparameter.L2Norm             = 1; % {0,1}
    modelparameter.output_tempresults = 0;   % {0,1}
    modelparameter.randomgenerate     = 0;   % {0,1}
    modelparameter.splitpercentage    = 0.8; %[0,1]
    modelparameter.tuneThreshold      = 0;   % {0,1}
end