% This is an examplar file on how the VLSF program could be used. Please
% cite our paper [1] if you want to use this program code.
% [1] J. Huang, X. Qu and G. Li, F. Qin, X. Zheng and Q. Huang, "Multi-View Multi-Label Learning With View-Label-Specific Features"
%     IEEE Access: 2019, 7, pp. 100979-100992
% Please feel free to contact me (huangjun_cs@163.com), if you have any problem about this programme.

clc
addpath(genpath('.'));
% addpath('../../com');
% addpath('../../evaluation');

starttime = datestr(now,0);
fprintf('Start Run VLSF at time:%s \n',starttime);
%% Initialization
dataType = 1;% 1: pascal, 2:other multimodal data
[optmParameter,modelparameter] =  initialization;
MultiViewDataIndication = SetMultiViewDataIndicate(dataType);

time = zeros(1,modelparameter.cv_num);
%% Set the Training and Test data
train_set = cell(MultiViewDataIndication.totalNumViews,1);
test_set  = cell(MultiViewDataIndication.totalNumViews,1);
num_views = MultiViewDataIndication.totalNumViews;

if dataType == 1 || dataType == 3
    index = 1;
    if MultiViewDataIndication.DenseHue 
        train_set{index} = train_DenseHue;
        test_set{index} = test_DenseHue;
        index = index + 1;
    end
    if MultiViewDataIndication.DenseHueV3H1
        train_set{index} = train_DenseHueV3H1;
        test_set{index} = test_DenseHueV3H1;
        index = index + 1;
    end
    if MultiViewDataIndication.DenseSift
        train_set{index} = train_DenseSift;
        test_set{index} = test_DenseSift;
        index = index + 1;
    end
    if MultiViewDataIndication.DenseSiftV3H1
        train_set{index} = train_DenseSiftV3H1;
        test_set{index} = test_DenseSiftV3H1;
        index = index + 1;
    end
    if MultiViewDataIndication.Gist
        train_set{index} = train_Gist;
        test_set{index} = test_Gist;
        index = index + 1;
    end
    if MultiViewDataIndication.HarrisHue
        train_set{index} = train_HarrisHue;
        test_set{index} = test_HarrisHue;
        index = index + 1;
    end
    if MultiViewDataIndication.HarrisHueV3H1
        train_set{index} = train_HarrisHueV3H1;
        test_set{index} = test_HarrisHueV3H1;
        index = index + 1;
    end
    if MultiViewDataIndication.HarrisSift
        train_set{index} = train_HarrisSift;
        test_set{index} = test_HarrisSift;
        index = index + 1;
    end
    if MultiViewDataIndication.HarrisSiftV3H1
        train_set{index} = train_HarrisSiftV3H1;
        test_set{index} = test_HarrisSiftV3H1;
        index = index + 1;
    end
    if MultiViewDataIndication.Hsv
       train_set{index} = train_Hsv;
       test_set{index} = test_Hsv;
       index = index + 1; 
    end
    if MultiViewDataIndication.HsvV3H1
       train_set{index} = train_HsvV3H1;
       test_set{index} = test_HsvV3H1;
       index = index + 1; 
    end
    if MultiViewDataIndication.Lab
       train_set{index} = train_Lab;
       test_set{index} = test_Lab;
       index = index + 1; 
    end
    if MultiViewDataIndication.LabV3H1
       train_set{index} = train_LabV3H1;
       test_set{index} = test_LabV3H1;
       index = index + 1;  
    end
    if MultiViewDataIndication.Rgb
       train_set{index} = train_Rgb;
       test_set{index} = test_Rgb;
       index = index + 1;  
    end
    if MultiViewDataIndication.RgbV3H1
       train_set{index} = train_RgbV3H1;
       test_set{index} = test_RgbV3H1;
       index = index + 1;  
    end
    if MultiViewDataIndication.tags
       train_set{index} = train_tags;
       test_set{index} = test_tags;
       index = index + 1; 
    end
end

if exist('test_target','var')
    dataMVML = CombineTrainTest(train_set, test_set, num_views);
end
clear train_set test_set
%%
if dataType == 3
    train_target = double(train_tags);
    test_target = double(test_tags);
    target = [train_target',test_target'];
else
    if exist('test_target','var')
        target=[train_target,test_target];
    end
end
target = target';
%% Procedures of Training and Test for VLSF

fprintf('Running VLSF\n');  

%% cross validation
num_data = size(dataMVML{1},1);
for i = 1:num_views
    dataMVML{i} = normalization(dataMVML{i}, 'l2', 1);
end
randorder = randperm(num_data);
cvResult  = cell(modelparameter.cv_num,1);
models = cell(modelparameter.cv_num,1);
for cv = 1:modelparameter.cv_num
    fprintf('Cross Validation - %d/%d\n', cv, modelparameter.cv_num);
    [cvTrainSet,cvTrain_target,cvTestSet,cvTest_target ] = generateMultiViewCVSet(dataMVML, target, randorder, cv, modelparameter.cv_num);
    tic
    cvVLSF   = VLSF(cvTrainSet, double(cvTrain_target), optmParameter, num_views);
    fprintf('\nMulti-view multi-label classification results:\n---------------------------------------------\n');
    cvResult{cv} = VLSF_Predict(cvTestSet, cvTest_target', cvVLSF, modelparameter, cvTrainSet, cvTrain_target')
    models{cv} = cvVLSF;
    time(1,cv) = toc;
end
[Avg_Result, averagetime] = PrintVLSFAvgResult(cvResult, time, modelparameter.cv_num);

model_VLSF.randorder = randorder;
model_VLSF.optmParameter = optmParameter;
model_VLSF.modelparameter = modelparameter;
model_VLSF.MultiViewDataIndication = MultiViewDataIndication;
model_VLSF.models = models;
model_VLSF.cvResult = cvResult;
model_VLSF.avg_Result = Avg_Result;
model_VLSF.averagetime = averagetime;
endtime = datestr(now,0);
fprintf('End Run VLSF at time:%s \n',endtime);
