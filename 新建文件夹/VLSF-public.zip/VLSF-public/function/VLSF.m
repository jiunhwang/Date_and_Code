
function [model_VLSF] = VLSF( X_set, Y, optmParameter, num_views)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function is designed to learning the label specific features each label of each data view
%    Syntax
%
%       [model_VLSF] = VLSF( X_set, Y, optmParameter, num_views)
%
%    Input
%       X               - a n by d data matrix, n is the number of instances and d is the number of features 
%       Y               - a n by l label matrix, n is the number of instances and l is the number of labels
%       optmParameter   - A struct variable with seven fields, the optimization parameters for VLSF
%   Output
%
%       model_VLSF  - a d by l Coefficient matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %% optimization parameters
    lambda1          = optmParameter.lambda1;
    lambda2          = optmParameter.lambda2;
    lambda3          = optmParameter.lambda3;
    lambda4          = optmParameter.lambda4;
    eta              = optmParameter.eta;
    maxIter          = optmParameter.maxIter;
    miniLossMargin   = optmParameter.minimumLossMargin;
   %% Initialization
    [W_set, XTX_set, XTY_set] = InitializeW_set(X_set,Y, optmParameter);
    W_set_t = W_set;
    P = 1 - pdist2( Y'+eps, Y'+eps, 'cosine' );
    iter = 1;
    loss = 0;
    oldloss = 0;
    bk = 1; bk_1 = 1; u_k = 1;
    theta = ones(num_views,1)/num_views;
    prediction_Loss       = zeros(num_views,1);
    trace_Ws_loss = zeros(num_views,1);
    trace_consistent_loss = zeros(num_views,1);
    spares_Ws_loss = zeros(num_views,1);
    
    XiTXj_set = calculate_XiTXj(X_set);
   %% Optimization
    L = diag(sum(P,2)) - P;
    Lip_P = sqrt(norm(Y'*Y)^2);
    while iter <= maxIter
       if optmParameter.outputthetaQ
           fprintf('- iter - %d/%d\n', iter, maxIter);
       end
       F_v = calculateF(X_set, W_set, Y, L, theta, lambda1, lambda2, lambda3, lambda4);
       QL_v = calculateQ(X_set, W_set, Y, theta, lambda1, lambda2, lambda3, lambda4, W_set_t, L, theta, XTX_set,XTY_set,XiTXj_set,Lip_P);
       while F_v > QL_v
           Lip_P = eta*Lip_P;
           QL_v = calculateQ(X_set, W_set, Y, theta, lambda1, lambda2, lambda3, lambda4, W_set_t, L, theta, XTX_set,XTY_set,XiTXj_set,Lip_P);
       end
       
      %% update the coefficiency matrices {W_v}_{v=1}^m
       for v = 1: num_views
           W_s_k  = W_set{v,1} + (bk_1 - 1)/bk * (W_set{v,1} - W_set_t{v,1});
           Gw_s_k = W_s_k - 1/Lip_P * u_k*fun_gradient(XTX_set{v,1}, XTY_set{v,1}, W_s_k, L, XiTXj_set, v, theta(v,1), lambda1, lambda2, W_set, theta);
           
           W_set_t{v,1}  = W_set{v,1};
           W_set{v,1}    = softthres(Gw_s_k,lambda1/Lip_P);
           
           prediction_Loss(v,1) = trace((X_set{v,1}*W_set{v,1} - Y)'*(X_set{v,1}*W_set{v,1} - Y)); % prediction loss
           trace_Ws_loss(v) = trace( W_set{v,1}*L* W_set{v,1}'); % pairwise correlation
           trace_consistent_loss(v) = calculate_ConsistentLoss(X_set, W_set, theta, v); %  consistency between two different views
           spares_Ws_loss(v)   = sum(sum(W_set{v}~=0)); % sparsity of Wv's
       end 
       
      %% update theta: Coordinate descent
       if optmParameter.updateTheta == 1
           theta  = updateTheta(theta, lambda4, prediction_Loss);
       end
       
       bk_1 = bk;
       bk   = (1 + sqrt(4*bk^2 + 1))/2;

       if optmParameter.outputthetaQ == 1
           fprintf(' - prediction loss: ');
           for mm=1:num_views
                fprintf('%e, ', prediction_Loss(mm));
           end
           fprintf('\n - theta: ');
           for mm=1:num_views
                fprintf('%.3f, ', theta(mm));
           end
           fprintf('\n');
       end
      %% value of the objective function
       PredictLoss      = (theta'*prediction_Loss)/2;
       CorrelationLoss  = sum(trace_Ws_loss)/2;
       ConsistentLoss   = sum(trace_consistent_loss)/2;
       SparseLossW      = sum(spares_Ws_loss);
       LossTheta        = theta'*theta;
       totalloss = PredictLoss + lambda3*CorrelationLoss + lambda2*ConsistentLoss+ lambda1*SparseLossW + lambda4*LossTheta/2;
       if abs(oldloss - totalloss) <= miniLossMargin
           break;
       elseif totalloss <=0
           break;
       else
           oldloss = totalloss;
       end
       
       if loss == 0
           loss = totalloss;
       elseif loss >= 0
           loss = [loss,totalloss];
       end
       iter=iter+1;
    end
    % return values
    model_VLSF.W = W_set;
    model_VLSF.theta = theta;
    model_VLSF.loss = loss;
end


%% the gradient of the objective function for each view
function grad = fun_gradient(XTX, XTY, W_i, L, XiTXj_set, i, theta_i, lambda2, lambda3, W_set, theta)
    num_views = size(XiTXj_set,1);
    Sum_XiTXjWj = zeros(size(W_i));
    t=0;
    for j = 1:num_views
        if j~=i
            hij = 1/(abs(theta(i)-theta(j))+1/num_views);
            Sum_XiTXjWj = Sum_XiTXjWj + hij*XiTXj_set{i,j}*W_set{j};
            t = t + hij;
        end
    end
    grad = (theta_i + t*lambda2) * XTX * W_i - theta_i*XTY - lambda2*Sum_XiTXjWj + lambda3*W_i*L';
end

%% calculate Xi^T * Xj
function XiTXj_set = calculate_XiTXj(X_set)
    m = size(X_set,1);
    XiTXj_set = cell(m,m);
    for i = 1:m-1
        for j = i+1:m
            XiTXj_set{i,j} = X_set{i}'*X_set{j};
            XiTXj_set{j,i} = XiTXj_set{i,j}';
        end
    end
end

%% soft thresholding operator
function W = softthres(W_t,lambda)
    W = max(W_t-lambda,0) - max(-W_t-lambda,0);  
end

function [W_set, XTX_set, XTY_set] = InitializeW_set(X_set,Y, optmParameter)
    m = size(X_set,1);
    num_class = size(Y,2);
    W_set   = cell(m,1);
    XTX_set = cell(m,1);
    XTY_set = cell(m,1);
    
    for i = 1:m
        XTX_set{i,1} = X_set{i,1}' * X_set{i,1};
        XTY_set{i,1} = X_set{i,1}' * double(Y);
        num_dim      = size(X_set{i,1},2);
        if optmParameter.ru ~=0 
            W_set{i,1}   = (XTX_set{i,1} + optmParameter.ru*eye(num_dim)) \ (XTY_set{i,1});
        else
            W_set{i,1} = zeros(num_dim, num_class);
        end
    end
end

function consistentLoss = calculate_ConsistentLoss(X_set, W_set, theta, i)
    num_views = size(X_set,1);
    consistentLoss = 0;
    
    for j = 1:num_views
       if j ~=i
           hij = 1/(abs(theta(i)-theta(j))+1/num_views);
           consistentLoss = consistentLoss + hij*trace( (X_set{i}*W_set{i} - X_set{j}*W_set{j})' * (X_set{i}*W_set{i} - X_set{j}*W_set{j}) );
       end
    end
end

function [theta_t ] = updateTheta(theta, lambda, q)
    m = length(theta);
    negative = 0;
    theta_t = zeros(m,1);
    
    for i =1:m
       theta_t(i,1) = (lambda+sum(q) - m*q(i))/(m*lambda);
       if theta_t(i,1) < 0
           negative = 1;
           theta_t(i,1) = 0.0000001;
       end
    end
    if negative == 1
       theta_t = theta_t./sum(theta_t);
    end
end

function F_v = calculateF(X_set, W_set, Y, L, theta, lambda1, lambda2, lambda3, lambda4)
% calculate the value of function F(\Theta)
    F_v = 0;
    num_views = size(X_set,1);
    for v = 1:num_views
        F_v = F_v + theta(v,1)*0.5*trace((X_set{v,1}*W_set{v,1}  - Y)'*(X_set{v,1}*W_set{v,1} - Y)); % prediction loss
        F_v = F_v + lambda3*0.5*trace( W_set{v,1}*L* W_set{v,1}'); % pairwise correlation
        F_v = F_v + lambda2*0.5*calculate_ConsistentLoss(X_set, W_set, theta, v); %  consistency between two different views
        F_v = F_v + lambda1*sum(sum(W_set{v}~=0)); % sparsity of Wv's
    end
    F_v = F_v + lambda4*(theta')*theta;
end

function QL_v = calculateQ(X_set, W_set, Y, theta, lambda1, lambda2, lambda3, lambda4, W_set_t, L, theta_t,XTX_set,XTY_set,XiTXj_set,Lip)
% calculate the value of function Q_L(w_v,w_v_t)
    QL_v = 0;
    num_views = size(X_set,1);
    for v = 1:num_views
        QL_v = QL_v + theta(v,1)*0.5*trace((X_set{v,1}*W_set_t{v,1} - Y)'*(X_set{v,1}*W_set_t{v,1} - Y)); % prediction loss
        QL_v = QL_v + lambda3*0.5*trace( W_set_t{v,1}*L* W_set_t{v,1}'); % pairwise correlation
        QL_v = QL_v + lambda2*0.5*calculate_ConsistentLoss(X_set, W_set_t, theta_t, v); %  consistency between two different views
        QL_v = QL_v + 0.5*Lip*norm( W_set{v,1} -  W_set_t{v,1},'fro')^2;
        QL_v = QL_v + trace((W_set{v,1} -  W_set_t{v,1})'*fun_gradient(XTX_set{v,1}, XTY_set{v,1}, W_set_t{v,1}, L, XiTXj_set, v, theta_t(v,1), lambda2, lambda3, W_set_t, theta_t));
        QL_v = QL_v + lambda1*sum(sum(W_set{v}~=0)); % sparsity of Wv's
    end
    QL_v = QL_v + lambda4*(theta_t')*theta_t;
end

