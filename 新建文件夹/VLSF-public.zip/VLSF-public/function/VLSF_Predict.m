
function result = VLSF_Predict(Xtest_set, Ytest, model_VLSF, modelparameter, Xtrain_set, Ytrain)
%% Input
%   Xtest_set         -  m by 1 cell, and each cell is a data matrix with
%                        respect to the i-th view
%   Ytest             -  L by N_est data matrix
%   model_VLSF        -  a structure variable, and it contains the coefficience and theta
% Output            
%   result            -  16x1matrix, results of multi-view multi-label classification
% ------------------------------------------------------------------------------------------------------
    num_views = size(Xtest_set,1);
    [num_class,num_test] = size(Ytest);
    result = zeros(16,1);
    VLSF_funsion_outputs = zeros(num_class,num_test);
    for i = 1:num_views
        Outputs      = double(Xtest_set{i} * model_VLSF.W{i,1});
        Outputs      = Outputs';
        VLSF_funsion_outputs    = VLSF_funsion_outputs + model_VLSF.theta(i).*Outputs;
    end
   %% VLSF funsion
    threshold = tuneThresholdMVML(Xtrain_set, Ytrain, model_VLSF, modelparameter);
    Pre_Labels   = VLSF_funsion_outputs >= threshold(1,1); 
    Pre_Labels   = double(Pre_Labels);
    result(:,1)  = EvaluationAll(Pre_Labels,VLSF_funsion_outputs,Ytest);
end

function threshold = tuneThresholdMVML(Xtrain_set, Ytrain, model_VLSF, modelparameter)
    num_views = size(Xtrain_set,1);
    VLSF_funsion_outputs = zeros(size(Ytrain'));
    for i = 1:num_views
        VLSF_funsion_outputs  = VLSF_funsion_outputs + double(Xtrain_set{i} * model_VLSF.W{i,1}*model_VLSF.theta(i));
    end
    [ threshold,  ~] = TuneThreshold( VLSF_funsion_outputs', Ytrain, 1, modelparameter.tuneThresholdType);
end