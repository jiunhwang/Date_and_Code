function [Outputs, Pre_Labels] = LPLC(test_data, train_data, train_target, num_k,PositiveCorrelationMatrix, NegativeCorrelationMatrix, alpha)
%% Multi Label KNN k-Nearest Neighbors Algorithm. Latest version
%
%   INPUT:  test_data         - testing sample features, P-by-N_test matrix.
%           train_data        - training sample features, P-by-N matrix.
%           train_target      - training sample labels, 1-by-N row vector.
%           num_k             - the k in k-Nearest Neighbors
%   OUTPUT: predict_target    - predicted labels, num_label-by-N_test row vector.

    disp('- Begin Runing LPLC: Local Pairwise Label Correlation');
    [num_class,num_train] = size(train_target);
    num_test = size(test_data,1);
    Pre_Labels = zeros(num_class,num_test);
    Outputs = zeros(num_class,num_test);
    
    userview = memory;
    max_mat_elements = (userview.MaxPossibleArrayBytes)/8;
    max_mat_elements = (max_mat_elements*0.2)/5; 
   
    if(num_train*num_test<max_mat_elements) 
        mat1=concur(sum(train_data.^2,2),num_test);
        mat2=concur(sum(test_data.^2,2),num_train)';
        dist_matrix=mat1+mat2-2*train_data*test_data';
        dist_matrix=sqrt(dist_matrix);
        dist_matrix=dist_matrix';
        
        dist=ones(num_test,num_train);
        dist_matrix=dist_matrix+dist;
        dist_matrix=dist./dist_matrix;
        [temp,index]=sort(dist_matrix,2,'descend'); 
    
        disp('- Testing');
        for i=1:num_test
            kneighbors=train_target(:,index(i,2:num_k+1))';
            Prob=zeros(2,num_class);
            for j=1:num_class 
                classset = unique(kneighbors(:,j));
                [r,c] = size(classset);
                if c==r
                    Pre_Labels(j,i) = classset; 
                    if classset==1
                        Outputs(j,i)=1; 
                    else
                        Outputs(j,i)=0.1*rand; 
                    end
                else
                    K = num_k;
                    positiveclass_idx = find(kneighbors(:,j)==1);
                    negativeclass_idx = setdiff([1:num_k],positiveclass_idx);
                    num_positve = length(positiveclass_idx);  
                    num_negative = length(negativeclass_idx);
                    Prob(1,j) = num_positve/K; 
                    Prob(2,j) = num_negative/K; 
                    kneighborsPositiveCorrelatedLabels = PositiveCorrelationMatrix(index(i,2:num_k+1),:);               
                    PositiveDependentLabels = kneighborsPositiveCorrelatedLabels(:,j);
                    PositiveDependentLabels = unique(PositiveDependentLabels);
                    PositiveParentLabels = PositiveDependentLabels(find(PositiveDependentLabels~=0));
                    kneighborsNegativeCorrelatedLabels = NegativeCorrelationMatrix(index(i,2:num_k+1),:);  
                    NegativeDependentLabels = kneighborsNegativeCorrelatedLabels(:,j);
                    NegativeDependentLabels = unique(NegativeDependentLabels);
                    NegaitveParentLabels = NegativeDependentLabels(find(NegativeDependentLabels~=0));
                    
                    Pr=zeros(1,2);
                    Pr(1,1) = Prob(1,j);
                    Pr(1,2) = Prob(2,j);                    
                    for m = 1:length(PositiveParentLabels)
                        Pa_l = PositiveParentLabels(m);
                        if sum(kneighbors(:,Pa_l))~=0
                            PrPositive = sum(kneighbors(:,j) & kneighbors(:,Pa_l))/sum(kneighbors(:,Pa_l));
                            Pr(1,1) = Pr(1,1) + PrPositive* (sum(kneighbors(:,Pa_l))/K);
                            Pr(1,2) = Pr(1,2) + (1-PrPositive) * (sum(kneighbors(:,Pa_l))/K);    
                        end
                    end
                    pnegative = zeros(1,2);
                    for m = 1:length(NegaitveParentLabels)
                        Pa_l = NegaitveParentLabels(m);
                        NegativeKNNPa = 1 - kneighbors(:,Pa_l);  
                        if sum(NegativeKNNPa)~=0
                            PrPositive = sum(kneighbors(:,j) & NegativeKNNPa)/sum(NegativeKNNPa);
                            PrNegative = (1-alpha)*(1 - PrPositive);
                            pnegative(1,1) = pnegative(1,1) + PrPositive * (sum(NegativeKNNPa)/K);
                            pnegative(1,2) = pnegative(1,2) + PrNegative * (sum(NegativeKNNPa)/K);
                        end
                    end
                    Pr(1,1) = Pr(1,1) * alpha + pnegative(1,1)*(1-alpha); 
                    Pr(1,2) = Pr(1,2) * alpha + pnegative(1,2)*(1-alpha); 
                    Pr(1,1)=Pr(1,1)/(Pr(1,1)+Pr(1,2));
                    p_postive = Pr(1,1);
                    p_negative = 1 - Pr(1,1);
                    if  p_postive >= p_negative
                        Pre_Labels(j,i) =1;
                    end
                    Outputs(j,i)=p_postive/( p_postive + p_negative);
                end
            end
        end
    else 
        block_size=floor(max_mat_elements/num_train); 
        num_blocks=ceil(num_test/block_size);
        disp('----------------------------------------------');
        disp('- Out of memory, split the test data to blocks');
        disp('----------------------------------------------');
        fprintf('\n');
        for iter=1:num_blocks
            disp(['- Process block ',num2str(iter),'/',num2str(num_blocks)]);
            low=block_size*(iter-1)+1;
            if(iter==num_blocks)
                high=num_test;
                testnums=num_test-low+1;
            else
                high=block_size*iter;
                testnums=block_size;
            end
            
            mat1=concur(sum(train_data.^2,2),testnums);
            mat2=concur(sum(test_data(low:high,:).^2,2),num_train)';
            dist_matrix=mat1+mat2-2*train_data*test_data(low:high,:)';
            dist_matrix=sqrt(dist_matrix);
            dist_matrix=dist_matrix'; 
            dist=ones(testnums,num_train);
            dist_matrix=dist_matrix+dist;
            dist_matrix=dist./dist_matrix;
            [temp,index]=sort(dist_matrix,2,'descend'); 
 
            disp('- Testing');
            for i=low:high
                kneighbors=train_target(:,index(i-block_size*(iter-1),2:num_k+1))';
                Prob=zeros(2,num_class);
                for j=1:num_class           
                    classset=unique(kneighbors(:,j));
                    [r,c]=size(classset);
                    if c==r
                        Pre_Labels(j,i)=classset;
                        if classset==1
                            Outputs(j,i)=1;
                        end
                    else
                        K = num_k; 
                        positiveclass_idx=find(kneighbors(:,j)==1);
                        negativeclass_idx=setdiff([1:num_k],positiveclass_idx);
                        num_positve=length(positiveclass_idx);  
                        num_negative=length(negativeclass_idx);
                        Prob(1,j) = num_positve/K; 
                        Prob(2,j) = num_negative/K; 

                        kneighborsPositiveCorrelatedLabels=PositiveCorrelationMatrix(index(i-block_size*(iter-1),1:num_k),:);            
                        PositiveDependentLabels=kneighborsPositiveCorrelatedLabels(:,j);
                        PositiveDependentLabels=unique(PositiveDependentLabels);
                        PositiveParentLabels=PositiveDependentLabels(find(PositiveDependentLabels~=0));
                        
                        kneighborsNegativeCorrelatedLabels = NegativeCorrelationMatrix(index(i-block_size*(iter-1),1:num_k),:);  
                        NegativeDependentLabels = kneighborsNegativeCorrelatedLabels(:,j);
                        NegativeDependentLabels = unique(NegativeDependentLabels);
                        NegaitveParentLabels = NegativeDependentLabels(find(NegativeDependentLabels~=0));
                        Pr=zeros(1,2);
                        Pr(1,1) = Prob(1,j);
                        Pr(1,2) = Prob(2,j);                                  
                        for m = 1:length(PositiveParentLabels)
                            Pa_l = PositiveParentLabels(m);
                            if sum(kneighbors(:,Pa_l))~=0
                                PrPositive = sum(kneighbors(:,j) & kneighbors(:,Pa_l))/sum(kneighbors(:,Pa_l));
                                Pr(1,1) = Pr(1,1) + PrPositive* (sum(kneighbors(:,Pa_l))/K);
                                Pr(1,2) = Pr(1,2) + (1-PrPositive) * (sum(kneighbors(:,Pa_l))/K);    
                            end
                        end
                        pnegative = zeros(1,2);
                        for m = 1:length(NegaitveParentLabels)
                            Pa_l = NegaitveParentLabels(m);
                            NegativeKNNPa = 1 - kneighbors(:,Pa_l);  
                            if sum(NegativeKNNPa)~=0
                                PrPositive = sum(kneighbors(:,j) & NegativeKNNPa)/sum(NegativeKNNPa);
                                PrNegative = (1-alpha)*(1 - PrPositive);
                                pnegative(1,1) = pnegative(1,1) + PrPositive * (sum(NegativeKNNPa)/K);
                                pnegative(1,2) = pnegative(1,2) + PrNegative * (sum(NegativeKNNPa)/K);
                            end
                        end
                        Pr(1,1) = Pr(1,1) * alpha + pnegative(1,1)*(1-alpha); 
                        Pr(1,2) = Pr(1,2) * alpha + pnegative(1,2)*(1-alpha); 
                        Pr(1,1)=Pr(1,1)/(Pr(1,1)+Pr(1,2));
                        positiveavgsim=1;
                        negativeavgsim=1;
                        p_postive = positiveavgsim * Pr(1,1);
                        p_negative = negativeavgsim * (1 - Pr(1,1));
                        if  p_postive >= p_negative
                            Pre_Labels(j,i) =1;
                        end
                        Outputs(j,i)=p_postive/( p_postive + p_negative);
                    end
                end
            end
        end      
    end
    disp('- End Runing LPLC: Local Pairwise Label Correlation');
    fprintf('\n')
end
