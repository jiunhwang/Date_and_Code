
starttime = datestr(now,0);
clc 
addpath('evaluation');

model_LPLC.crossvalidation = 1; 
model_LPLC.num_k  = [3 5 7 9 11 13 15 17 19 21]; 
model_LPLC.cv_num = 5;
model_LPLC.L2Norm = 1;
model_LPLC.splitpercentage = 0.8; 
model_LPLC.alpha = 0.7;

ResultAll       = zeros(11,length(model_LPLC.num_k));
ResultAllStd    = zeros(11,length(model_LPLC.num_k));

if model_LPLC.crossvalidation==0 
   if model_LPLC.L2Norm == 1
       train_data = train_data./repmat(sqrt(sum(train_data.^2,2)),1,size(train_data,2));
       test_data = test_data./repmat(sqrt(sum(test_data.^2,2)),1,size(test_data,2));
   end
else
    if exist('train_data','var')==1
        data=[train_data;test_data];
        target=[train_target,test_target];
        clear train_data test_data train_target test_target
    end

    tempdata = data;
    if model_LPLC.L2Norm == 1
        tempdata = tempdata./repmat(sqrt(sum(tempdata.^2,2)),1,size(tempdata,2));
    end
    num_data = size(tempdata,1);
end

for i=1:length(model_LPLC.num_k)   
    Result          = zeros(11,model_LPLC.cv_num);
    for j=1:model_LPLC.cv_num
        disp(['Cross Validation - ',num2str(j),'/',num2str(model_LPLC.cv_num), '  k= ',num2str(model_LPLC.num_k(i))]);   
        
        randorder = randperm(num_data);
        num_train=round(num_data * model_LPLC.splitpercentage); 

        cv_train_data=tempdata(randorder(1:num_train),:);
        cv_train_target=target(:,randorder(1:num_train));
        cv_test_data=tempdata(randorder(num_train+1:num_data),:);
        cv_test_target=target(:,randorder(num_train+1:num_data));

        [PositiveCorrelationMatrix, NegativeCorrelationMatrix] = LearnCorrelationMatrix(cv_train_data, cv_train_target, model_LPLC.num_k(i));
        [Outputs,Pre_Labels] = LPLC(cv_test_data, cv_train_data, cv_train_target, model_LPLC.num_k(i),PositiveCorrelationMatrix, NegativeCorrelationMatrix, model_LPLC.alpha);

        Result(:,j) = Evaluate(Pre_Labels,cv_test_target)
    end

    ResultAll(:,i) = mean(Result,2)
    ResultAllStd(:,i) = std(Result,1,2);

    model_LPLC.ResultAll = ResultAll;
    model_LPLC.ResultAllStd = ResultAllStd;

end

endtime = datestr(now,0);


