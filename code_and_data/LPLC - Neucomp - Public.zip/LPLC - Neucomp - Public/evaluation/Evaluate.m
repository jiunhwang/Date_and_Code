
function ResultAll = Evaluate(Pre_Labels,test_target)
% evluation for MLC algorithms
% 
% syntax
%   ResultAll = EvaluationAll(Pre_Labels,test_target)
%
% input
%   test_targets        - L x num_test data matrix of groundtruth labels
%   Pre_Labels          - L x num_test data matrix of predicted labels
%
% output
%     ResultAll
%     ResultAll(1,1)=HammingLoss;
%     ResultAll(2,1)=ExampleBasedAccuracy; 
%     ResultAll(3,1)=ExampleBasedPrecision; 
%     ResultAll(4,1)=ExampleBasedRecall; 
%     ResultAll(5,1)=ExampleBasedFmeasure;
% 
%     ResultAll(6,1)=SubsetAccuracy;
%     ResultAll(7,1)=LabelBasedAccuracy; 
%     ResultAll(8,1)=LabelBasedPrecision;
%     ResultAll(9,1)=LabelBasedRecall; 
%     ResultAll(10,1)=LabelBasedFmeasure; 
% 
%     ResultAll(11,1)=MicroF1Measure;

    ResultAll=zeros(11,1); 

    HammingLoss    = Hamming_loss(Pre_Labels,test_target);
    SubsetAccuracy = SubsetAccuracyEvaluation(test_target,Pre_Labels);
    
    [ExampleBasedAccuracy,ExampleBasedPrecision,ExampleBasedRecall,ExampleBasedFmeasure] = ExampleBasedMeasure(test_target,Pre_Labels);
    [LabelBasedAccuracy,LabelBasedPrecision,LabelBasedRecall,LabelBasedFmeasure] = LabelBasedMeasure(test_target,Pre_Labels);
    MicroF1Measure      = MicroFMeasure(test_target,Pre_Labels);
    
    
    ResultAll(1,1)  = HammingLoss;
    ResultAll(2,1)  = ExampleBasedAccuracy; 
    ResultAll(3,1)  = ExampleBasedPrecision; 
    ResultAll(4,1)  = ExampleBasedRecall; 
    ResultAll(5,1)  = ExampleBasedFmeasure;

    ResultAll(6,1)  = SubsetAccuracy;
    ResultAll(7,1)  = LabelBasedAccuracy; 
    ResultAll(8,1)  = LabelBasedPrecision;
    ResultAll(9,1)  = LabelBasedRecall; 
    ResultAll(10,1) = LabelBasedFmeasure; 

    ResultAll(11,1) = MicroF1Measure;
end