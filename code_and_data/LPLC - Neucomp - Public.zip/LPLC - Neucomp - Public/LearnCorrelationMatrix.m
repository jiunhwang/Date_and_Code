function [PositiveCorrelationMatrix, NegativeCorrelationMatrix] = LearnCorrelationMatrix(train_data, train_target, num_k)

    disp('- Train Maximun Conditional Labels ');
    [num_class,num_train]=size(train_target);
    PositiveCorrelationMatrix = zeros(num_train, num_class);
    NegativeCorrelationMatrix = zeros(num_train, num_class);
    
    Outputs=zeros(num_class,num_train);
    
    userview=memory;
    max_mat_elements=(userview.MaxPossibleArrayBytes)/8;
    max_mat_elements=(max_mat_elements*0.2)/10;
 
    if(num_train*num_train<max_mat_elements) 
        mat1=concur(sum(train_data.^2,2),num_train);
        mat2=concur(sum(train_data.^2,2),num_train)';
        dist_matrix = mat1+ mat2-2 * train_data*train_data';
        dist_matrix=sqrt(dist_matrix);
        dist_matrix=dist_matrix';

        dist=ones(num_train,num_train);
        dist_matrix=dist_matrix+dist;
        dist_matrix=dist./dist_matrix;
        [temp,index]=sort(dist_matrix,2,'descend');

        for i=1:num_train
            kneighbors = train_target(:,index(i,2:num_k+1))';
            Prob = zeros(2,num_class);
            for j=1:num_class           
                if train_target(j,i)==1 
                    positiveclass_idx=find(kneighbors(:,j)==1);
                    negativeclass_idx=setdiff([1:num_k],positiveclass_idx);
                    Prob(1,j) = length(positiveclass_idx)/num_k; 
                    Prob(2,j) = length(negativeclass_idx)/num_k; 
                    Outputs(j,i)=Prob(1,j)/(Prob(1,j)+Prob(2,j));
                    p1=Prob(1,j)/(Prob(1,j)+Prob(2,j));
                    best_pcur = p1;
                    bestsup=0;
                    
                    for l=1:num_class
                       if l~=j && train_target(l,i)==1 
                           if sum(kneighbors(:,l))~=0
                               p = sum( kneighbors(:,j) & kneighbors(:,l))/sum(kneighbors(:,l));
                               if p>=best_pcur
                                  best_pcur=p;
                                  bestsup = sum(kneighbors(:,l));
                                  PositiveCorrelationMatrix(i,j)=l;
                               elseif p==best_pcur 
                                   if sum(kneighbors(:,l)) > bestsup 
                                       best_pcur=p;
                                       bestsup=sum(kneighbors(:,l));
                                       PositiveCorrelationMatrix(i,j)=l;
                                   end
                               end
                           end
                       elseif l~=j && train_target(l,i)==0 
                           negativeKNN_L = 1 - kneighbors(:,l);
                           best_pcur = p1;
                           if sum(negativeKNN_L)~=0
                               p = sum( kneighbors(:,j) & negativeKNN_L)/sum(negativeKNN_L);
                               if p>=best_pcur
                                  best_pcur=p;
                                  bestsup=sum(negativeKNN_L);
                                  NegativeCorrelationMatrix(i,j)=l;
                               elseif p==best_pcur
                                   if sum(kneighbors(:,l)) > bestsup
                                       best_pcur=p;
                                       bestsup=sum(negativeKNN_L);
                                       NegativeCorrelationMatrix(i,j)=l;
                                   end
                               end
                           end
                       end 
                    end
                end 
            end 
        end 
    else
        num_test=num_train;
        block_size=floor(max_mat_elements/num_train); 
        num_blocks=ceil(num_test/block_size); 
        disp('----------------------------------------------');
        disp('- Out of memory, split the test data to blocks');
        disp('----------------------------------------------');
        fprintf('\n');
        for iter=1:num_blocks
            disp(['- Process block ',num2str(iter),'/',num2str(num_blocks)]);
            low=block_size*(iter-1)+1;
            if(iter==num_blocks)
                high=num_test;
                testnums=num_test-low+1;
            else
                high=block_size*iter;
                testnums=block_size;
            end
            
            test_data=train_data(low:high,:);
            mat1=concur(sum(train_data.^2,2),testnums);
            mat2=concur(sum(test_data.^2,2),num_train)';
            
            dist_matrix=mat1+mat2-2*train_data*test_data';
            dist_matrix=sqrt(dist_matrix);
            dist_matrix=dist_matrix';
        
            dist=ones(testnums,num_train);
            dist_matrix=dist_matrix+dist;
            dist_matrix=dist./dist_matrix;
            [temp,index]=sort(dist_matrix,2,'descend'); 
            
            for i=low:high
                kneighbors=train_target(:,index(i-block_size*(iter-1),1:num_k))';
                Prob=zeros(2,num_class);
                 for j=1:num_class           
                    if train_target(j,i)==1
                        positiveclass_idx=find(kneighbors(:,j)==1);
                        negativeclass_idx=setdiff([1:num_k],positiveclass_idx);
                        Prob(1,j) = length(positiveclass_idx)/num_k; 
                        Prob(2,j) = length(negativeclass_idx)/num_k;
                        best_pcur = 0.5;
                        bestsup=0;
                        best_curPN = 0.5;
                        for l=1:num_class
                           if l~=j && train_target(l,i)==1
                               fenmu = sum( ( kneighbors(:,j) + kneighbors(:,l))~=0);
                               p = sum( kneighbors(:,j) & kneighbors(:,l))/ fenmu;
                               if p>=best_pcur
                                  best_pcur=p;
                                  bestsup=sum(kneighbors(:,l));
                                  PositiveCorrelationMatrix(i,j)=l;
                               end
                            elseif l~=j && train_target(l,i)==0 
                               negativeKNN_L = 1 - kneighbors(:,l);
                               fenmu = sum( ( kneighbors(:,j) + negativeKNN_L)~=0);
                               if sum(negativeKNN_L)~=0
                                   p = sum( kneighbors(:,j) & negativeKNN_L)/fenmu;
                                   if p>=best_curPN
                                      best_curPN = p;
                                      bestsup=sum(negativeKNN_L);
                                      NegativeCorrelationMatrix(i,j)=l;
                                   end
                               end   
                            end
                        end 
                    end
                 end
            end
        end
    end 
end
